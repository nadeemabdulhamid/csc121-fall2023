package model;

  
public interface BPMObserver {
	void updateBPM();
}
