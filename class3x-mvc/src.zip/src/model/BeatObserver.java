package model;

  
public interface BeatObserver {
	void updateBeat();
}
