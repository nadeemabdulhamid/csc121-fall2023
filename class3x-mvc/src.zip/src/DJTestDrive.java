import controller.BeatController;
import controller.IDJController;
import model.BeatModel;
import model.IDJModel;

public class DJTestDrive {

    public static void main (String[] args) {
        IDJModel model = new BeatModel();
		IDJController controller = new BeatController(model);
    }
}
